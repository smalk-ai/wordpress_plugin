<?php

// User

function smalk_get_user() {
    $cached_user = get_option(SMALK_AI_USER);
    return $cached_user !== false ? $cached_user : false;
}

// User Helpers

function smalk_get_user_is_analytics_disallowed() {
    $access_token = get_option(SMALK_AI_ACCESS_TOKEN);
    if ($access_token) {
        $user = smalk_get_user();
        return isset($user['is_analytics_allowed']) ? !$user['is_analytics_allowed'] : false;
    } else {
        // If no access token, treat analytics as disallowed.
        return true;
    }
}

function smalk_get_user_analytics_script_tag() {
    $access_token = get_option(SMALK_AI_ACCESS_TOKEN);
    
    if (!$access_token) {
        return '';
    }
    
    $api_url = 'https://api.smalk.me/api/v1/projects';
    
    $headers = array(
        'Content-Type' => 'application/json',
        'Authorization' => 'Api-Key ' . $access_token
    );
    
    $response = wp_remote_get($api_url, array(
        'headers' => $headers
    ));
    
    if (smalk_is_network_response_code_successful($response)) {
        $project = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!empty($project) && isset($project['id'])) {
            $project_id = $project['id'];
            return sprintf(
                '<script src="https://api.smalk.me/tracker.js?PROJECT_KEY=%s"></script>',
                esc_attr($project_id)
            );
        }
    }
    
    // Return empty string if we couldn't get the project ID
    return '';
}

// Caching

function smalk_clear_caches($option_name) {
    $cache_clearing_option_names = array(
        SMALK_AI_ACCESS_TOKEN,
        SMALK_AI_IS_ANALYTICS_ENABLED
    );

    if (in_array($option_name, $cache_clearing_option_names)) {
        delete_option(SMALK_AI_USER_AGENT_STRINGS_LIST);
        delete_option(SMALK_AI_ROBOTS_TXT);
        delete_option(SMALK_AI_USER);
    }
}
add_action('update_option', 'smalk_clear_caches');


function smalk_get_robots_txt() {
    $cached_robots_txt = get_option(SMALK_AI_ROBOTS_TXT);

    if ($cached_robots_txt === false) {
        return smalk_refresh_and_return_robots_txt();
    } else {
        return $cached_robots_txt;
    }
}

// Cron Jobs

add_action(SMALK_AI_DAILY_CRON_EVENT, 'smalk_refresh_and_return_user_agent_strings_list');
add_action(SMALK_AI_DAILY_CRON_EVENT, 'smalk_refresh_and_return_robots_txt');
add_action(SMALK_AI_EVERY_FIVE_MINUTES_CRON_EVENT, 'smalk_refresh_and_return_user');

// Helpers

function smalk_is_network_response_code_successful($response) {
    return !is_wp_error($response) && 
           wp_remote_retrieve_response_code($response) >= 200 && 
           wp_remote_retrieve_response_code($response) < 300;
}